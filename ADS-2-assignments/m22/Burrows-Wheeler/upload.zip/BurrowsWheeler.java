import java.util.Arrays;
import java.util.HashMap;

public class BurrowsWheeler {
  public static void encode() {
  String s = BinaryStdIn.readString();
  CircularSuffixArray arr = new CircularSuffixArray(s);
  char[] result = new char[arr.length()];
  int first = -1;
  for (int i=0; i<arr.length(); i++) {
   int pos = arr.index(i);
   if (pos == 0) {
    first = i;
   }
   pos = (pos - 1 + arr.length()) % (arr.length());
   result[i] = s.charAt(pos);
  }
  BinaryStdOut.write(first);
  for (int i=0; i<result.length; i++) {
	  BinaryStdOut.write(result[i]);
  }
  BinaryStdOut.flush();
  BinaryStdOut.close();
  return;
 } 
 public static void decode() {
  int first = BinaryStdIn.readInt();
  String s = BinaryStdIn.readString();
  char[] arr = s.toCharArray();
  if (first > arr.length) return;
  boolean[] visited = new boolean[arr.length];
  Arrays.fill(visited, false);
  char[] front = new char[arr.length];
  for (int i=0; i<arr.length; i++) front[i] = arr[i];
  Arrays.sort(front);
  int[] next = new int[arr.length];
  int cur = 0;
  HashMap<Character, Queue<Integer>> map = new HashMap<Character, Queue<Integer>>();
  for (int i=0; i<arr.length; i++) {
	  if (map.containsKey(arr[i])) {
		  map.get(arr[i]).enqueue(i);
	  }
	  else {
		  Queue<Integer> q = new Queue<Integer>();
		  q.enqueue(i);
		  map.put(arr[i], q);
	  }
  }
  for (int i=0; i<front.length; i++) {
	  int ans = map.get(front[i]).dequeue();
	  next[i] = ans;
  }
  char[] result = new char[arr.length];
  cur = first;
  for (int i=0; i<arr.length; i++) {
   result[i] = front[cur];
   cur = next[cur];
   BinaryStdOut.write(result[i]);  
  }
  BinaryStdOut.flush();
  BinaryStdOut.close();
  return;
 }
 public static void main(String[] args) {
  if (args[0].equals("-"))
   BurrowsWheeler.encode();
  if (args[0].equals("+"))
   BurrowsWheeler.decode();
  return;
 }
}