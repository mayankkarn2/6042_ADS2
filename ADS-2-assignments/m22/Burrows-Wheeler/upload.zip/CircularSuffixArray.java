import java.util.Arrays;

public class CircularSuffixArray {
    
    private int len;
    private int[] pos;
    private String s;
    
    private class Node implements Comparable<Node> {
        private int index;
        
        public Node(int index) {
            this.index = index;
        }       

        public int getIndex() { return index; }     
        
        @Override
        public int compareTo(Node arg) {
            int j = arg.getIndex();
            for (int i=0; i<length(); i++) {
                int pos1 = (i + index + length()) % length();
                int pos2 = (i + j + length()) % length();
                if (s.charAt(pos1) != s.charAt(pos2))
                    return s.charAt(pos1) - s.charAt(pos2);
            }
            return 0;
        }
        
    }
    
    public CircularSuffixArray(String s) {       
        this.pos = new int[s.length()];
        this.len = s.length();
        this.s = s;
        Node[] suffix = new Node[s.length()];
        for (int i=0; i<suffix.length; i++) {
            suffix[i] = new Node(i);
        }
        Arrays.sort(suffix);
        for (int i=0; i<pos.length; i++) {          
            pos[i] = suffix[i].getIndex();
        }
    }
    
    public int length() {
        return this.len;
    }
    
    public int index(int i) {
        return pos[i];
    }
    public static void main(String[] args) {
        CircularSuffixArray arr = new CircularSuffixArray("ABRACADABRA!");
        for (int i=0; i<arr.length(); i++) {
            System.out.println(arr.index(i));
        }
    }    
}