public class MoveToFront {
	public static void encode() {
    	char[] pos = new char[256];
    	for (int i=0; i<pos.length; i++) pos[i] = (char)i;
    	while (BinaryStdIn.isEmpty() == false) {
    		char c = BinaryStdIn.readChar();    		
    		for (int i=0; i<pos.length; i++) {
    			if (pos[i] == c) {
    				BinaryStdOut.write((char)i);
    				for (int j=i; j>0; j--) pos[j] = pos[j-1];
    				pos[0] = c;
    				break;
    			}
    		}
    	}
    	BinaryStdOut.flush();
    	BinaryStdOut.close();
    	return;
    }
    public static void decode() {
    	char[] pos = new char[256];
    	for (int i=0; i<pos.length; i++) pos[i] = (char)i;    	
    	while (BinaryStdIn.isEmpty() == false) {
    		char c = BinaryStdIn.readChar();
    		BinaryStdOut.write(pos[c]);
    		char tmp = pos[c];
            for (int i=c; i>0; i--) pos[i] = pos[i-1];
    		pos[0] = tmp;
    	}
    	BinaryStdOut.flush();
    	BinaryStdOut.close();
    	return;
    } 
	public static void main(String[] args) {
		MoveToFront move = new MoveToFront();
		if (args[0].equals("-"))
			move.encode();
		if (args[0].equals("+"))
			move.decode();
		return;
	}
}